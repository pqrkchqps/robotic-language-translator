//Generated Machine.h for Box

#include "runtime.h"

//declarations of the state classes
class State_Init;

class State_MoveNorth;

class State_MoveEast;

class State_MoveSouth;

class State_MoveWest;

class Box_Machine {
