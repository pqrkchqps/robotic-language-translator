#ifndef READINPUT_H
#define READINPUT_H

char *readInput (int argc, char **argv) ;

char *readInputFromFile (const char *filename) ;

#endif /* READINPUT_H */
